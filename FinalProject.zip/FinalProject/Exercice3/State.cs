﻿using System;
namespace FinalProject
{
    public abstract class State
    {
        public abstract void Play(Player player);
    }
}
